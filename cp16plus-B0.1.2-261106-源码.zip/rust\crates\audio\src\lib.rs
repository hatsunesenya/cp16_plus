//! 实时采集（cpal 后端）+ 发射播放（同一个 cpal，输出设备可选）。
//!
//! 为什么用 cpal 而不是自写 WASAPI：真实使用场景里必须**能选输入设备**
//! （电台的 USB 声卡、SDR 的虚拟声卡，都不是"默认麦克风"），
//! 而设备枚举/格式协商/重采样这些细节 cpal 已经处理得足够稳。
//! 采集线程只做一件事：交错样本 → 单声道 f32 → 通道。
//!
//! 发射侧：引擎按 UTC 整十秒对齐后调用 `play()`，阻塞到音频播完。
//! 输出设备同样可选——电台通常接在一块特定的 USB 声卡上。

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::Arc;

use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};

pub struct SourceConfig {
    /// None = 系统默认输入
    pub device: Option<String>,
    /// None = 设备默认采样率
    pub sample_rate: Option<u32>,
    /// 保留字段（cpal 不提供回环；用虚拟声卡设备名代替）
    pub loopback: bool,
}

impl Default for SourceConfig {
    fn default() -> Self {
        SourceConfig { device: None, sample_rate: None, loopback: false }
    }
}

pub struct Capture {
    _stream: cpal::Stream,
    rx: Receiver<Vec<f32>>,
    pub fs: u32,
    pub channels: u16,
    pub name: String,
}

impl Capture {
    pub fn recv(&self) -> Option<Vec<f32>> {
        self.rx.recv_timeout(std::time::Duration::from_millis(500)).ok()
    }
}

/// 列出全部输入设备名（给界面做设备选择）。
pub fn list_devices() -> Vec<String> {
    let host = cpal::default_host();
    match host.input_devices() {
        Ok(devs) => devs.filter_map(|d| d.name().ok()).collect(),
        Err(_) => Vec::new(),
    }
}

/// 列出全部输出设备名（发射侧选择用）。
pub fn list_output_devices() -> Vec<String> {
    let host = cpal::default_host();
    match host.output_devices() {
        Ok(devs) => devs.filter_map(|d| d.name().ok()).collect(),
        Err(_) => Vec::new(),
    }
}

pub fn default_device_name() -> Option<String> {
    cpal::default_host().default_input_device().and_then(|d| d.name().ok())
}

pub fn default_output_device_name() -> Option<String> {
    cpal::default_host().default_output_device().and_then(|d| d.name().ok())
}

pub fn open(cfg: &SourceConfig) -> Result<Capture, String> {
    let host = cpal::default_host();
    let device = match &cfg.device {
        Some(name) => host
            .input_devices()
            .map_err(|e| format!("枚举输入设备失败: {e}"))?
            .find(|d| d.name().map(|n| n == *name).unwrap_or(false))
            .ok_or_else(|| format!("找不到输入设备 {name}"))?,
        None => host.default_input_device().ok_or("没有可用的默认输入设备")?,
    };
    let name = device.name().unwrap_or_else(|_| "?".into());

    let supported = device
        .default_input_config()
        .map_err(|e| format!("读设备配置失败: {e}"))?;
    let fs = supported.sample_rate().0;
    let channels = supported.channels();
    let cfg_built: cpal::StreamConfig = supported.config();

    let (tx, rx): (Sender<Vec<f32>>, Receiver<Vec<f32>>) = channel();
    let ch = channels as usize;
    let err_fn = |e| eprintln!("采集错误: {e}");

    // 设备可能给 i16/u16/f32，三种都接
    let stream = match supported.sample_format() {
        cpal::SampleFormat::F32 => device.build_input_stream(
            &cfg_built,
            move |data: &[f32], _: &_| {
                let mut mono = Vec::with_capacity(data.len() / ch.max(1));
                for frame in data.chunks(ch) {
                    mono.push(frame.iter().sum::<f32>() / ch as f32);
                }
                let _ = tx.send(mono);
            },
            err_fn,
            None,
        ),
        cpal::SampleFormat::I16 => device.build_input_stream(
            &cfg_built,
            move |data: &[i16], _: &_| {
                let mut mono = Vec::with_capacity(data.len() / ch.max(1));
                for frame in data.chunks(ch) {
                    let acc: i32 = frame.iter().map(|v| *v as i32).sum();
                    mono.push(acc as f32 / (ch as f32 * 32768.0));
                }
                let _ = tx.send(mono);
            },
            err_fn,
            None,
        ),
        cpal::SampleFormat::U16 => device.build_input_stream(
            &cfg_built,
            move |data: &[u16], _: &_| {
                let mut mono = Vec::with_capacity(data.len() / ch.max(1));
                for frame in data.chunks(ch) {
                    let acc: i32 = frame.iter().map(|v| *v as i32 - 32768).sum();
                    mono.push(acc as f32 / (ch as f32 * 32768.0));
                }
                let _ = tx.send(mono);
            },
            err_fn,
            None,
        ),
        other => return Err(format!("不支持的样本格式 {other:?}")),
    }
    .map_err(|e| format!("打开输入流失败: {e}"))?;

    stream.play().map_err(|e| format!("启动采集失败: {e}"))?;
    Ok(Capture { _stream: stream, rx, fs, channels, name })
}

// ---------------------------------------------------------------- 发射播放

/// 8 kHz 单声道 → 设备采样率/声道数（线性插值 + 6 点平滑，把镜像压下去）。
fn resample_for_output(x: &[f32], fs_in: u32, fs_out: u32, channels: usize) -> Vec<f32> {
    let ratio = fs_out as f64 / fs_in as f64;
    let n_out = ((x.len() as f64) * ratio).ceil() as usize + 8;
    let mut mono = Vec::with_capacity(n_out);
    for i in 0..n_out {
        let pos = i as f64 / ratio;
        let i0 = pos.floor() as usize;
        let frac = pos - i0 as f64;
        let a = *x.get(i0).unwrap_or(&0.0);
        let b = *x.get(i0 + 1).unwrap_or(&a);
        mono.push(a + (b - a) * frac as f32);
    }
    // 简易滑动平均（长度 ≈ 上采样倍数），压掉插值镜像
    let k = (ratio.round() as usize).max(1).min(8);
    if k > 1 {
        let mut acc = 0.0f32;
        let mut buf = vec![0.0f32; mono.len()];
        for i in 0..mono.len() {
            acc += mono[i];
            if i >= k {
                acc -= mono[i - k];
            }
            buf[i] = acc / k as f32;
        }
        mono = buf;
    }
    let mut out = Vec::with_capacity(mono.len() * channels);
    for v in mono {
        for _ in 0..channels {
            out.push(v);
        }
    }
    out
}

/// 播放期间的取样器：把整段音频按缓冲区需要逐块吐出去。
/// `cancel` 一置位就立刻吐静音并把游标推到末尾——这样阻塞中的 `play()` 会在
/// 一个缓冲区（十几毫秒）内返回，用来支持"发射中途打断"。
#[derive(Clone)]
struct Feeder {
    data: Arc<Vec<f32>>,
    pos: Arc<AtomicUsize>,
    cancel: Arc<std::sync::atomic::AtomicBool>,
}

impl Feeder {
    fn fill(&self, buf: &mut [f32]) {
        if self.cancel.load(Ordering::Relaxed) {
            for slot in buf.iter_mut() {
                *slot = 0.0;
            }
            self.pos.store(self.data.len(), Ordering::Relaxed);
            return;
        }
        let at = self.pos.load(Ordering::Relaxed);
        for (i, slot) in buf.iter_mut().enumerate() {
            let idx = at + i;
            *slot = if idx < self.data.len() { self.data[idx] } else { 0.0 };
        }
        self.pos.fetch_add(buf.len(), Ordering::Relaxed);
    }
}

/// 阻塞播放一段 8 kHz 单声道音频；返回实际使用的输出设备名。
/// `cancel` 置位即中断（播放线程会在一个缓冲区内退出）。
pub fn play(
    x: &[f32],
    fs_in: u32,
    device: Option<&str>,
    cancel: Arc<std::sync::atomic::AtomicBool>,
) -> Result<String, String> {
    let host = cpal::default_host();
    let dev = match device {
        Some(name) if !name.is_empty() => host
            .output_devices()
            .map_err(|e| format!("枚举输出设备失败: {e}"))?
            .find(|d| d.name().map(|n| n == name).unwrap_or(false))
            .ok_or_else(|| format!("找不到输出设备 {name}"))?,
        _ => host.default_output_device().ok_or("没有可用的默认输出设备")?,
    };
    let name = dev.name().unwrap_or_else(|_| "?".into());
    let supported = dev
        .default_output_config()
        .map_err(|e| format!("读输出配置失败: {e}"))?;
    let cfg = supported.config();
    let fs_out = supported.sample_rate().0;
    let channels = cfg.channels as usize;
    let feeder = Feeder {
        data: Arc::new(resample_for_output(x, fs_in, fs_out, channels)),
        pos: Arc::new(AtomicUsize::new(0)),
        cancel,
    };
    let total = feeder.data.len();
    let err_fn = |e| eprintln!("播放错误: {e}");

    let f32_feeder = feeder.clone();
    let i16_feeder = feeder.clone();
    let stream = match supported.sample_format() {
        cpal::SampleFormat::F32 => dev.build_output_stream(
            &cfg,
            move |buf: &mut [f32], _: &_| f32_feeder.fill(buf),
            err_fn,
            None,
        ),
        cpal::SampleFormat::I16 => {
            let mut scratch: Vec<f32> = vec![0.0; 4096];
            dev.build_output_stream(
                &cfg,
                move |buf: &mut [i16], _: &_| {
                    let n = buf.len();
                    if scratch.len() < n {
                        scratch.resize(n, 0.0);
                    }
                    i16_feeder.fill(&mut scratch[..n]);
                    for i in 0..n {
                        buf[i] = (scratch[i].clamp(-1.0, 1.0) * 32767.0) as i16;
                    }
                },
                err_fn,
                None,
            )
        }
        other => return Err(format!("不支持的输出样本格式 {other:?}")),
    }
    .map_err(|e| format!("打开发射流失败: {e}"))?;

    stream.play().map_err(|e| format!("启动发射失败: {e}"))?;
    // 等播完（多等 120 ms，让设备缓冲排空）
    while feeder.pos.load(Ordering::Relaxed) < total {
        std::thread::sleep(std::time::Duration::from_millis(15));
    }
    std::thread::sleep(std::time::Duration::from_millis(120));
    drop(stream);
    Ok(name)
}
