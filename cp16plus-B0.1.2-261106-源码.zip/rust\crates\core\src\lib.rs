﻿//! CP16+ 协议核心（无第三方依赖，便于原生产品与 WASM 双编译）。
//!
//! 与 Python 参考实现一一对应，见 `docs/porting.md`。
//! 数值约定：内部一律 f64，音频出口降 f32；样点索引用 i64。

pub mod complex;
pub mod crc;
pub mod fec;
pub mod font;
pub mod frame;
pub mod modem;
pub mod params;
pub mod pilot;
pub mod png;
pub mod preambles;
pub mod rt;
pub mod rx;
pub mod tx;
pub mod vision;
pub mod wav;

pub use complex::C64;
pub use params::{Mode, MODES};
